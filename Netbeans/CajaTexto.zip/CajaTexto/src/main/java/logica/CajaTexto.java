/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package logica;

/**
 *
 * @author PILARES
 */
public class CajaTexto {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
